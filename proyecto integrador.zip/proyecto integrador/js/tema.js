// js/tema.js
// Toggle robusto: crea/activa hojas oscuras y persiste la preferencia en localStorage.
// Incluye mapeo adicional: style.css <-> style-dark.css

(function () {
  const STORAGE_KEY = 'modoOscuroActivo';

  // Mapa: archivo claro -> archivo oscuro (solo nombres de archivo)
  const MAPA = {
    'style.css': 'style-dark.css',
    'main.css': 'mainnegro.css',
    'main1.css': 'negrofav.css',
    'csscajero.css': 'csscajeronegro.css'
  };

  // Extrae el nombre de archivo final de un href (sin query/hash)
  function nombreArchivo(href) {
    if (!href) return '';
    return href.split('/').pop().split('?')[0].split('#')[0];
  }

  // Reemplaza la última parte del href por nuevoNombre manteniendo la carpeta
  function construirHrefConNuevoNombre(originalHref, nuevoNombre) {
    if (!originalHref) return nuevoNombre;
    const partes = originalHref.split('/');
    partes[partes.length - 1] = nuevoNombre;
    return partes.join('/');
  }

  // Crea (si no existe) un <link> para la versión oscura y lo deja desactivado (media="none")
  function asegurarLinkOscuro(linkClaro, nombreOscuro) {
    const head = document.head || document.getElementsByTagName('head')[0];
    const hrefOscuro = construirHrefConNuevoNombre(linkClaro.href, nombreOscuro);

    // Si ya existe un link con ese nombre oscuro, devolverlo
    const existentes = Array.from(document.querySelectorAll('link[rel="stylesheet"]'));
    const ya = existentes.find(l => nombreArchivo(l.getAttribute('href') || '') === nombreOscuro);
    if (ya) return ya;

    // Crear nuevo link oscuro desactivado por defecto
    const nuevo = document.createElement('link');
    nuevo.rel = 'stylesheet';
    nuevo.href = hrefOscuro;
    nuevo.media = 'none'; // desactivado hasta que se active el modo oscuro
    nuevo.setAttribute('data-tema-oscuro', nombreOscuro);
    head.appendChild(nuevo);
    return nuevo;
  }

  // Buscar links claros y asegurar sus pares oscuros
  function prepararLinks() {
    const links = Array.from(document.querySelectorAll('link[rel="stylesheet"]'));
    links.forEach(link => {
      const href = link.getAttribute('href') || link.href || '';
      const nombre = nombreArchivo(href);

      // Si el nombre está en el mapa, asegurar su oscuro
      if (MAPA[nombre]) {
        asegurarLinkOscuro(link, MAPA[nombre]);
        return;
      }

      // Heurística: si el href contiene una clave del mapa, asegurar su oscuro
      Object.keys(MAPA).forEach(claro => {
        if (href.includes(claro) && !href.includes(MAPA[claro])) {
          asegurarLinkOscuro(link, MAPA[claro]);
        }
      });
    });
  }

  // Aplica modo: true = oscuro, false = claro
  function aplicarModo(modoOscuro) {
    const links = Array.from(document.querySelectorAll('link[rel="stylesheet"]'));
    links.forEach(link => {
      const href = link.getAttribute('href') || '';
      const nombre = nombreArchivo(href);

      // Si es un link oscuro creado por nosotros (tiene data-tema-oscuro o nombre en MAPA values)
      if (link.hasAttribute('data-tema-oscuro') || Object.values(MAPA).includes(nombre)) {
        link.media = modoOscuro ? 'all' : 'none';
        return;
      }

      // Si es un link claro (filename en MAPA keys), activarlo solo en modo claro
      if (Object.keys(MAPA).includes(nombre)) {
        link.media = modoOscuro ? 'none' : 'all';
        return;
      }

      // Links no mapeados se mantienen activos siempre
      link.media = 'all';
    });

    // Actualizar atributo del botón si existe
    const btn = document.getElementById('btn-tema');
    if (btn) btn.setAttribute('aria-pressed', String(modoOscuro));
  }

  // Mostrar toast (Toastify si existe, fallback simple)
  function mostrarToast(mensaje) {
    if (typeof Toastify !== 'undefined') {
      Toastify({
        text: mensaje,
        duration: 2200,
        gravity: 'top',
        position: 'right',
        style: { background: '#222', color: '#fff' }
      }).showToast();
    } else {
      const el = document.createElement('div');
      el.textContent = mensaje;
      el.style.position = 'fixed';
      el.style.top = '16px';
      el.style.right = '16px';
      el.style.padding = '10px 14px';
      el.style.background = '#222';
      el.style.color = '#fff';
      el.style.borderRadius = '8px';
      el.style.zIndex = 99999;
      document.body.appendChild(el);
      setTimeout(() => el.remove(), 2200);
    }
  }

  // Alterna tema y guarda en localStorage
  function toggleTema() {
    const activo = localStorage.getItem(STORAGE_KEY) === 'true';
    const nuevo = !activo;
    aplicarModo(nuevo);
    localStorage.setItem(STORAGE_KEY, nuevo ? 'true' : 'false');
    mostrarToast(nuevo ? 'Modo oscuro activado' : 'Modo claro activado');
  }

  // Función de debug para consola: muestra links detectados y su estado
  function temaDebug() {
    const links = Array.from(document.querySelectorAll('link[rel="stylesheet"]')).map(l => ({
      href: l.getAttribute('href'),
      nombre: nombreArchivo(l.getAttribute('href') || ''),
      media: l.media,
      dataTemaOscuro: l.getAttribute('data-tema-oscuro') || null
    }));
    console.table(links);
    console.log('localStorage modoOscuroActivo =', localStorage.getItem(STORAGE_KEY));
  }

  // Inicializa al cargar
  function init() {
    prepararLinks();
    const guardado = localStorage.getItem(STORAGE_KEY);
    const modoOscuro = guardado === 'true';
    aplicarModo(modoOscuro);

    const btn = document.getElementById('btn-tema');
    if (btn) {
      btn.setAttribute('aria-pressed', String(modoOscuro));
      btn.addEventListener('click', (e) => { e.preventDefault(); toggleTema(); });
    }

    // Exponer utilidades para consola
    window.temaDebug = temaDebug;
    window.toggleTema = toggleTema;
    window.aplicarModo = aplicarModo;
  }

  document.addEventListener('DOMContentLoaded', init);
})();
