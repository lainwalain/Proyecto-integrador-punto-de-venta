<?php
// register.php
require_once __DIR__ . '/../db.php'; // ajusta ruta si es necesario

// Espera POST JSON o form-data
$username = $_POST['username'] ?? null;
$email = $_POST['email'] ?? null;
$password = $_POST['password'] ?? null;

if (!$username || !$email || !$password) {
    http_response_code(400);
    echo json_encode(['error'=>'Faltan campos']);
    exit;
}

// validar existencia
$stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
$stmt->execute([$username, $email]);
if ($stmt->fetch()) {
    http_response_code(409);
    echo json_encode(['error'=>'Usuario o email ya existe']);
    exit;
}

$hash = password_hash($password, PASSWORD_DEFAULT);
$role = 'user'; // por defecto

$ins = $pdo->prepare("INSERT INTO users (username, email, password_hash, role) VALUES (?, ?, ?, ?)");
$ins->execute([$username, $email, $hash, $role]);

echo json_encode(['ok'=>true, 'message'=>'Registro exitoso']);
