<?php
// login.php
session_start();
require_once __DIR__ . '/../db.php';

$usernameOrEmail = $_POST['username'] ?? null;
$password = $_POST['password'] ?? null;

if (!$usernameOrEmail || !$password) {
    http_response_code(400);
    echo json_encode(['error'=>'Faltan campos']);
    exit;
}

$stmt = $pdo->prepare("SELECT id, username, email, password_hash, role FROM users WHERE username = ? OR email = ?");
$stmt->execute([$usernameOrEmail, $usernameOrEmail]);
$user = $stmt->fetch();

if (!$user || !password_verify($password, $user['password_hash'])) {
    http_response_code(401);
    echo json_encode(['error'=>'Credenciales inválidas']);
    exit;
}

// Login OK: guardar sesión y devolver role para redirección
$_SESSION['user_id'] = $user['id'];
$_SESSION['username'] = $user['username'];
$_SESSION['role'] = $user['role'];

echo json_encode(['ok'=>true, 'role'=>$user['role']]);
