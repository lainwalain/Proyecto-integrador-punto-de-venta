/* ================================
   CONECTAR JS CON EL CAJERO
================================ */

const carritoProductos = document.getElementById("carrito-productos");
const totalTexto = document.getElementById("total");
const efectivoInput = document.getElementById("efectivo");
const cambioTexto = document.getElementById("cambio");
const cajaVacia = document.getElementById("carrito-vacio");

/* Renderizar productos del carrito en el cajero */
function renderCarrito() {
    carritoProductos.innerHTML = "";

    if (productosEnCarrito.length === 0) {
        cajaVacia.classList.remove("disabled");
        return;
    }

    cajaVacia.classList.add("disabled");

    productosEnCarrito.forEach(prod => {
        const div = document.createElement("div");
        div.classList.add("carrito-producto");

        div.innerHTML = `
            <img src="${prod.imagen}" alt="${prod.titulo}">
            <div class="info">
                <h3>${prod.titulo}</h3>
                <p class="precio">$${prod.precio}</p>
            </div>

            <div class="acciones">
                <input type="number" value="${prod.cantidad}" min="1" data-id="${prod.id}" class="cantidad-input">
                <button class="eliminar" data-id="${prod.id}">🗑️</button>
            </div>
        `;

        carritoProductos.append(div);
    });

    activarEventosCarrito();
    actualizarTotal();
}

/* Actualizar total */
function actualizarTotal() {
    let total = productosEnCarrito.reduce((acc, p) => acc + p.precio * p.cantidad, 0);
    totalTexto.innerText = `$${total.toFixed(2)}`;
    calcularCambio();
}

/* Calcular cambio */
function calcularCambio() {
    let efectivo = parseFloat(efectivoInput.value) || 0;
    let total = parseFloat(totalTexto.innerText.replace("$","")) || 0;
    let cambio = efectivo - total;

    cambioTexto.innerText = cambio.toFixed(2);
}

efectivoInput.addEventListener("input", calcularCambio);

/* Activar botones dentro del carrito */
function activarEventosCarrito() {
    document.querySelectorAll(".cantidad-input").forEach(input => {
        input.addEventListener("input", e => {
            let id = e.target.dataset.id;
            let prod = productosEnCarrito.find(p => p.id === id);
            prod.cantidad = Number(e.target.value);
            localStorage.setItem("productos-en-carrito", JSON.stringify(productosEnCarrito));
            actualizarTotal();
        });
    });

    document.querySelectorAll(".eliminar").forEach(btn => {
        btn.addEventListener("click", e => {
            let id = e.target.dataset.id;
            productosEnCarrito = productosEnCarrito.filter(p => p.id !== id);
            localStorage.setItem("productos-en-carrito", JSON.stringify(productosEnCarrito));
            renderCarrito();
        });
    });
}

/* --- Sobrescribo agregarAlCarrito para conectar el cajero --- */

function agregarAlCarrito(e) {
    Toastify({
        text: "Producto agregado",
        duration: 2000,
        gravity: "top",
        position: "right",
        close: true,
        style: { background: "#000" }
    }).showToast();

    const idBoton = e.currentTarget.id;
    const productoAgregado = productos.find(producto => producto.id === idBoton);

    if (!productoAgregado) return;

    const existe = productosEnCarrito.find(p => p.id === idBoton);

    if (existe) {
        existe.cantidad++;
    } else {
        productosEnCarrito.push({ ...productoAgregado, cantidad: 1 });
    }

    localStorage.setItem("productos-en-carrito", JSON.stringify(productosEnCarrito));

    actualizarNumerito();
    renderCarrito();
}
// Renderizar resultados de búsqueda de forma segura
function renderResultados(data) {
  const resultados = document.getElementById('resultados');
  if (!resultados) return;
  resultados.innerHTML = ''; // limpiar

  data.forEach(p => {
    const item = document.createElement('div');
    item.className = 'item-busqueda';

    // Título (nombre)
    const title = document.createElement('strong');
    title.textContent = p.name || p.nombre || 'Producto';

    // Precio (asegurar número)
    const precioNum = Number(p.price ?? p.precio ?? 0) || 0;
    const priceText = document.createTextNode(' - $' + precioNum.toFixed(2) + ' ');

    // Botón Agregar (sin inline onclick)
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.textContent = 'Agregar';
    btn.addEventListener('click', () => {
      const id = Number(p.id);
      const nombre = String(p.name ?? p.nombre ?? '');
      const precio = precioNum;
      // Llama a tu función agregar definida en el scope global
      if (typeof agregar === 'function') {
        agregar(id, nombre, precio);
      } else {
        console.warn('Función agregar no encontrada', id, nombre, precio);
      }
    });

    // Montar elementos
    item.appendChild(title);
    item.appendChild(priceText);
    item.appendChild(btn);
    resultados.appendChild(item);
  });
}

