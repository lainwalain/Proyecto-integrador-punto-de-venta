let productos = [];

fetch("js/productos.json")
    .then(response => response.json())
    .then(data => {
        productos = data;
        cargarProductos(productos);
    });

const contenedorProductos = document.querySelector("#contenedor-productos");
const botonesCategorias = document.querySelectorAll(".cat-btn");
const tituloPrincipal = document.querySelector("#titulo-principal");
let botonesAgregar = document.querySelectorAll(".producto-agregar");
let botonesFavorito = document.querySelectorAll(".producto-favorito");
const numerito = document.querySelector("#numerito");
const aside = document.querySelector("aside"); // CORRECCIÓN: definir aside

// Cerrar aside al hacer clic en cualquier categoría
botonesCategorias.forEach(boton => boton.addEventListener("click", () => {
    if (aside) aside.classList.remove("aside-visible");
}));

function cargarProductos(productosElegidos) {
    contenedorProductos.innerHTML = "";

    productosElegidos.forEach(producto => {
        const esFavorito = productosFavoritos.some(p => p.id === producto.id);

        const div = document.createElement("div");
        div.classList.add("producto");
        div.innerHTML = `
            <img class="producto-imagen" src="${producto.imagen}" alt="${producto.titulo}">
            <div class="producto-detalles">
                <h3 class="producto-titulo">${producto.titulo}</h3>
                <p class="producto-precio">$${producto.precio}</p>
                <div class="producto-botones">
                    <button class="producto-agregar" id="${producto.id}">Agregar</button>
                    <button class="producto-favorito ${esFavorito ? "favorito-activo" : ""}" data-id="${producto.id}">
                        ${esFavorito ? "❤️" : "🤍"}
                    </button>
                </div>
            </div>
        `;
        contenedorProductos.append(div);
    });

    actualizarBotonesAgregar();
    actualizarBotonesFavorito();
}

// FILTRADO POR CATEGORÍAS
botonesCategorias.forEach(boton => {
    boton.addEventListener("click", (e) => {
        e.preventDefault();

        // Quitar active a todos
        botonesCategorias.forEach(b => b.classList.remove("active"));
        e.currentTarget.classList.add("active");

        const categoriaSeleccionada = e.currentTarget.dataset.category;

        // Mostrar todos si es "todos"
        if (categoriaSeleccionada === "todos") {
            tituloPrincipal.innerText = "Todos los productos";
            cargarProductos(productos);
            return;
        }

        // Filtrar productos por categoria.id
        const productosFiltrados = productos.filter(
            producto => producto.categoria.id.toLowerCase() === categoriaSeleccionada.toLowerCase()
        );

        tituloPrincipal.innerText = productosFiltrados.length > 0 
            ? productosFiltrados[0].categoria.nombre 
            : "Sin productos";

        cargarProductos(productosFiltrados);
    });
});

function actualizarBotonesAgregar() {
    botonesAgregar = document.querySelectorAll(".producto-agregar");

    botonesAgregar.forEach(boton => {
        boton.addEventListener("click", agregarAlCarrito);
    });
}

function actualizarBotonesFavorito() {
    botonesFavorito = document.querySelectorAll(".producto-favorito");

    botonesFavorito.forEach(boton => {
        boton.addEventListener("click", toggleFavorito);
    });
}

let productosEnCarrito;
let productosEnCarritoLS = localStorage.getItem("productos-en-carrito");

if (productosEnCarritoLS) {
    productosEnCarrito = JSON.parse(productosEnCarritoLS);
    actualizarNumerito();
} else {
    productosEnCarrito = [];
}

function agregarAlCarrito(e) {
    Toastify({
        text: "Producto agregado",
        duration: 3000,
        close: true,
        gravity: "top",
        position: "right",
        stopOnFocus: true,
        style: {
            background: "linear-gradient(to right, #bc5ba2ff, #7700ffff)",
            borderRadius: "2rem",
            textTransform: "uppercase",
            fontSize: ".75rem"
        },
        offset: {
            x: '1.5rem',
            y: '1.5rem'
        },
        onClick: function () { }
    }).showToast();

    const idBoton = e.currentTarget.id;
    const productoAgregado = productos.find(producto => producto.id === idBoton);

    if (productosEnCarrito.some(producto => producto.id === idBoton)) {
        const index = productosEnCarrito.findIndex(producto => producto.id === idBoton);
        productosEnCarrito[index].cantidad++;
    } else {
        productoAgregado.cantidad = 1;
        productosEnCarrito.push(productoAgregado);
    }

    actualizarNumerito();
    localStorage.setItem("productos-en-carrito", JSON.stringify(productosEnCarrito));
}

function actualizarNumerito() {
    let nuevoNumerito = productosEnCarrito.reduce((acc, producto) => acc + producto.cantidad, 0);
    if (numerito) {
        numerito.innerText = nuevoNumerito;
    }
}

// FAVORITOS
let productosFavoritos = JSON.parse(localStorage.getItem("productos-favoritos")) || [];

function toggleFavorito(e) {
    const idProducto = e.currentTarget.dataset.id;
    const productoFavorito = productos.find(producto => producto.id === idProducto);
    const index = productosFavoritos.findIndex(p => p.id === idProducto);

    if (index === -1) {
        productosFavoritos.push(productoFavorito);
        e.currentTarget.classList.add("favorito-activo");
        e.currentTarget.innerText = "❤️";
        Toastify({
            text: "Agregado a favoritos ❤️",
            duration: 2000,
            gravity: "top",
            position: "left",
            style: {
                background: "linear-gradient(to right, #ff416c, #ff4b2b)",
                borderRadius: "2rem",
                fontSize: ".75rem"
            }
        }).showToast();
    } else {
        productosFavoritos.splice(index, 1);
        e.currentTarget.classList.remove("favorito-activo");
        e.currentTarget.innerText = "🤍";
        Toastify({
            text: "Eliminado de favoritos 💔",
            duration: 2000,
            gravity: "top",
            position: "left",
            style: {
                background: "#777",
                borderRadius: "2rem",
                fontSize: ".75rem"
            }
        }).showToast();
    }

    localStorage.setItem("productos-favoritos", JSON.stringify(productosFavoritos));
}