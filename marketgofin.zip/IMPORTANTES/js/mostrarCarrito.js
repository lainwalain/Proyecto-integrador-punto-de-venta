// 🛒 Mostrar carrito y actualizar total en cobro
function mostrarCarrito() {
  // Ocultar mensaje de vacío y mostrar contenedor
  carritoVacio.classList.add("disabled");
  contProductos.classList.remove("disabled");

  let total = 0;
  contProductos.innerHTML = "";

  carrito.forEach(p => {
    const subtotal = Number(p.precio) * p.cantidad;
    total += subtotal;
    contProductos.innerHTML += `
      <div class="producto">
        <img src="${p.imagen}" alt="${p.nombre}" width="40">
        ${p.nombre} x${p.cantidad} - $${subtotal.toFixed(2)}
      </div>`;
  });

  // 🔹 Actualizar el apartado de cobro
  const totalElement = document.getElementById("total");
  if (totalElement) {
    totalElement.textContent = "$" + total.toFixed(2);
  } else {
    console.error("No se encontró el elemento #total en el HTML");
  }
}
