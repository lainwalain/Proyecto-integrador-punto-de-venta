document.addEventListener("DOMContentLoaded", () => {
  const els = {
    languageSelect: document.getElementById("language-select"),
    toggleTheme: document.getElementById("toggle-theme"),
    cobroTitle: document.getElementById("cobro-title"),
    efectivoLabel: document.getElementById("efectivo-label"),
    totalLabel: document.getElementById("total-label"),
    vaciarBtn: document.getElementById("carrito-acciones-vaciar"),
    finalizarBtn: document.getElementById("finalizar"),
    cambioContainer: document.getElementById("cambio-label"),
    cambioSpan: document.getElementById("cambio"),
    footerText: document.getElementById("footer-text"),
    cajeroVacio: document.getElementById("carrito-vacio"),
    cajeroComprado: document.getElementById("carrito-comprado"),
    buscarInput: document.getElementById("buscar")
  };

  const translations = {
    es: {
      cobro: "COBRO",
      efectivo: "Efectivo recibido:",
      total: "Total:",
      vaciar: "Vaciar carrito",
      finalizar: "Finalizar Venta",
      cambioLabel: "Cambio:",
      footer: "© Market.GO — Todos los derechos reservados",
      vacio: "El cajero está vacío",
      comprado: "Gracias por tu compra",
      buscarPH: "Buscar producto o escanear código..."
    },
    en: {
      cobro: "CHECKOUT",
      efectivo: "Cash received:",
      total: "Total:",
      vaciar: "Empty cart",
      finalizar: "Finish Sale",
      cambioLabel: "Change:",
      footer: "© Market.GO — All rights reserved",
      vacio: "The cashier is empty",
      comprado: "Thank you for your purchase",
      buscarPH: "Search product or scan code..."
    }
  };

  function applyLanguage(lang) {
    const t = translations[lang] || translations.es;
    els.cobroTitle.textContent = t.cobro;
    els.efectivoLabel.textContent = t.efectivo;
    els.totalLabel.textContent = t.total;
    els.vaciarBtn.textContent = t.vaciar;
    els.finalizarBtn.textContent = t.finalizar;
    els.cambioContainer.innerHTML = `${t.cambioLabel} $<span id="cambio">${els.cambioSpan.textContent}</span>`;
    els.footerText.textContent = t.footer;
    els.cajeroVacio.textContent = t.vacio;
    const emoji = els.cajeroComprado.querySelector("i");
    els.cajeroComprado.textContent = t.comprado + " ";
    if (emoji) els.cajeroComprado.appendChild(emoji);
    els.buscarInput.placeholder = t.buscarPH;
    localStorage.setItem("language", lang);
    els.languageSelect.value = lang;
  }

  function applyTheme(theme) {
    const head = document.querySelector("head");
    let darkLink = document.getElementById("dark-theme-css");

    if (theme === "dark") {
      if (!darkLink) {
        darkLink = document.createElement("link");
        darkLink.rel = "stylesheet";
        darkLink.href = "csscajeronegro.css";
        darkLink.id = "dark-theme-css";
        head.appendChild(darkLink);
      }
      els.toggleTheme.textContent = "☀️ Modo Claro";
    } else {
      if (darkLink) darkLink.remove();
      els.toggleTheme.textContent = "🌙 Modo Oscuro";
    }

    localStorage.setItem("theme", theme);
  }

  // Inicializar
  const savedLang = localStorage.getItem("language") || "es";
  applyLanguage(savedLang);

  const savedTheme = localStorage.getItem("theme") || "light";
  applyTheme(savedTheme);

  // Listeners
  els.languageSelect.addEventListener("change", (e) => applyLanguage(e.target.value));
  els.toggleTheme.addEventListener("click", () => {
    const nextTheme = localStorage.getItem("theme") === "dark" ? "light" : "dark";
    applyTheme(nextTheme);
  });
});
