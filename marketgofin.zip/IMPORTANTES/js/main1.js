let productos = [];

// 🔗 Cargar productos desde la BD vía PHP
fetch("php/get_articulos.php")
    .then(response => response.json())
    .then(data => {
        productos = data;
        cargarProductos(productos);
    })
    .catch(err => console.error("Error cargando productos:", err));

const contenedorProductos = document.querySelector("#contenedor-productos");
const botonesCategorias = document.querySelectorAll(".cat-btn");
const tituloPrincipal = document.querySelector("#titulo-principal");
let botonesAgregar = document.querySelectorAll(".producto-agregar");
let botonesFavorito = document.querySelectorAll(".producto-favorito");
const numerito = document.querySelector("#numerito");
const aside = document.querySelector("aside");

// Cerrar aside al hacer clic en cualquier categoría
botonesCategorias.forEach(boton => boton.addEventListener("click", () => {
    if (aside) aside.classList.remove("aside-visible");
}));

function cargarProductos(productosElegidos) {
    contenedorProductos.innerHTML = "";

    if (productosElegidos.length === 0) {
        contenedorProductos.innerHTML = "<p>No hay productos disponibles</p>";
        return;
    }

    productosElegidos.forEach(producto => {
        const esFavorito = productosFavoritos.some(p => p.id === producto.id);

        const tituloMostrar = typeof producto.titulo === "object" 
            ? (localStorage.getItem("language") === "en" ? producto.titulo.en : producto.titulo.es) 
            : producto.titulo;

        const div = document.createElement("div");
        div.classList.add("producto");
        div.innerHTML = `
            <img class="producto-imagen" src="${producto.imagen}" alt="${tituloMostrar}">
            <div class="producto-detalles">
                <h3 class="producto-titulo">${tituloMostrar}</h3>
                <p class="producto-precio">$${producto.precio}</p>
                <p class="producto-stock">Disponibles: ${producto.existencia}</p>
                <div class="producto-botones">
                    <button class="producto-agregar" id="${producto.id}">Agregar</button>
                    <button class="producto-favorito ${esFavorito ? "favorito-activo" : ""}" data-id="${producto.id}">
                        ${esFavorito ? "❤️" : "🤍"}
                    </button>
                </div>
            </div>
        `;
        contenedorProductos.append(div);
    });

    actualizarBotonesAgregar();
    actualizarBotonesFavorito();
}

// FILTRADO POR CATEGORÍAS
botonesCategorias.forEach(boton => {
    boton.addEventListener("click", (e) => {
        e.preventDefault();
        botonesCategorias.forEach(b => b.classList.remove("active"));
        e.currentTarget.classList.add("active");

        const categoriaSeleccionada = e.currentTarget.dataset.category;

        if (categoriaSeleccionada === "todos") {
            tituloPrincipal.innerText = "Todos los productos";
            cargarProductos(productos);
            return;
        }

        const productosFiltrados = productos.filter(
            producto => producto.categoria.id.toLowerCase() === categoriaSeleccionada.toLowerCase()
        );

        tituloPrincipal.innerText = productosFiltrados.length > 0 
            ? productosFiltrados[0].categoria.nombre 
            : "Sin productos";

        cargarProductos(productosFiltrados);
    });
});

// 🔎 FILTRADO POR BÚSQUEDA
function filtrarProductos() {
    const busqueda = document.getElementById("busqueda").value.toLowerCase();
    const productosFiltrados = productos.filter(p => {
        const titulo = typeof p.titulo === "object" 
            ? (localStorage.getItem("language") === "en" ? p.titulo.en : p.titulo.es) 
            : p.titulo;
        return titulo.toLowerCase().includes(busqueda);
    });
    cargarProductos(productosFiltrados);
}

function actualizarBotonesAgregar() {
    botonesAgregar = document.querySelectorAll(".producto-agregar");
    botonesAgregar.forEach(boton => {
        boton.addEventListener("click", agregarAlCarrito);
    });
}

function actualizarBotonesFavorito() {
    botonesFavorito = document.querySelectorAll(".producto-favorito");
    botonesFavorito.forEach(boton => {
        boton.addEventListener("click", toggleFavorito);
    });
}

let productosEnCarrito = JSON.parse(localStorage.getItem("productos-en-carrito")) || [];
actualizarNumerito();

function agregarAlCarrito(e) {
    const idBoton = e.currentTarget.id;
    const productoAgregado = productos.find(producto => producto.id === idBoton);

    // Validar existencia
    const enCarrito = productosEnCarrito.find(p => p.id === idBoton);
    const cantidadActual = enCarrito ? enCarrito.cantidad : 0;

    if (cantidadActual >= productoAgregado.existencia) {
        Toastify({
            text: "No hay más existencia disponible",
            duration: 3000,
            gravity: "top",
            position: "right",
            style: {
                background: "linear-gradient(to right, #ff416c, #ff4b2b)",
                borderRadius: "2rem",
                fontSize: ".75rem"
            }
        }).showToast();
        return;
    }

    Toastify({
        text: "Producto agregado",
        duration: 3000,
        close: true,
        gravity: "top",
        position: "right",
        stopOnFocus: true,
        style: {
            background: "linear-gradient(to right, #bc5ba2ff, #7700ffff)",
            borderRadius: "2rem",
            textTransform: "uppercase",
            fontSize: ".75rem"
        },
        offset: { x: '1.5rem', y: '1.5rem' }
    }).showToast();

    if (enCarrito) {
        enCarrito.cantidad++;
    } else {
        productoAgregado.cantidad = 1;
        productosEnCarrito.push(productoAgregado);
    }

    actualizarNumerito();
    localStorage.setItem("productos-en-carrito", JSON.stringify(productosEnCarrito));
}

function actualizarNumerito() {
    let nuevoNumerito = productosEnCarrito.reduce((acc, producto) => acc + producto.cantidad, 0);
    if (numerito) numerito.innerText = nuevoNumerito;
}

// FAVORITOS
let productosFavoritos = JSON.parse(localStorage.getItem("productos-favoritos")) || [];

function toggleFavorito(e) {
    const idProducto = e.currentTarget.dataset.id;
    const productoFavorito = productos.find(producto => producto.id === idProducto);
    const index = productosFavoritos.findIndex(p => p.id === idProducto);

    if (index === -1) {
        productosFavoritos.push(productoFavorito);
        e.currentTarget.classList.add("favorito-activo");
        e.currentTarget.innerText = "❤️";
    } else {
        productosFavoritos.splice(index, 1);
        e.currentTarget.classList.remove("favorito-activo");
        e.currentTarget.innerText = "🤍";
    }

    localStorage.setItem("productos-favoritos", JSON.stringify(productosFavoritos));
}
