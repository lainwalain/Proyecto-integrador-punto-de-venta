const buscar = document.getElementById("buscar");
const resultados = document.getElementById("resultados");
const carritoVacio = document.getElementById("carrito-vacio");
const contProductos = document.getElementById("carrito-productos");

let carrito = [];

// 🔎 Buscar productos en BD
buscar.addEventListener("input", () => {
  const q = buscar.value.trim();
  if (q.length === 0) { resultados.innerHTML = ""; return; }

  fetch("php/buscar.php?busqueda=" + encodeURIComponent(q))
    .then(res => res.json())
    .then(data => {
      resultados.innerHTML = "";
      if (!Array.isArray(data) || data.length === 0) {
        resultados.innerHTML = "<div class='item-busqueda'>Sin resultados</div>";
        return;
      }
      data.forEach(p => {
        const item = document.createElement("div");
        item.classList.add("item-busqueda");
        item.innerHTML = `
          <img src="${p.imagen}" alt="${p.nombre}" width="50">
          <strong>${p.nombre}</strong> - $${Number(p.precio).toFixed(2)}
          <button onclick="agregar(${p.id}, '${p.nombre.replace(/'/g,"\\'")}', ${Number(p.precio)}, '${p.imagen}')">Agregar</button>
        `;
        resultados.appendChild(item);
      });
    })
    .catch(err => {
      console.error("Error buscador:", err);
      resultados.innerHTML = "<div class='item-busqueda'>Error en búsqueda</div>";
    });
});

// ➕ Agregar al carrito
function agregar(id, nombre, precio, imagen) {
  precio = Number(precio); // asegurar número
  const existente = carrito.find(p => p.id === id);
  if (existente) {
    existente.cantidad++;
  } else {
    carrito.push({ id, nombre, precio, imagen, cantidad: 1 });
  }
  mostrarCarrito();
  buscar.value = "";
  resultados.innerHTML = "";
}

// 🛒 Mostrar carrito y actualizar total en cobro
function mostrarCarrito() {
  carritoVacio.classList.add("disabled");
  contProductos.classList.remove("disabled");

  let total = 0;
  contProductos.innerHTML = "";

  carrito.forEach(p => {
    const subtotal = Number(p.precio) * p.cantidad;
    total += subtotal;
    contProductos.innerHTML += `
      <div class="producto">
        <img src="${p.imagen}" alt="${p.nombre}" width="40">
        ${p.nombre} x${p.cantidad} - $${subtotal.toFixed(2)}
      </div>`;
  });

  // 🔹 Actualizar el apartado de cobro
  const totalElement = document.getElementById("total");
  if (totalElement) {
    totalElement.textContent = "$" + total.toFixed(2);
  } else {
    console.error("No se encontró el elemento #total en el HTML");
  }
}

// 🗑 Vaciar carrito
document.getElementById("carrito-acciones-vaciar").addEventListener("click", () => {
  carrito = [];
  contProductos.innerHTML = "";
  document.getElementById("total").textContent = "$0.00";
  carritoVacio.classList.remove("disabled");
  contProductos.classList.add("disabled");
  document.getElementById("efectivo").value = "";
  document.getElementById("cambio").textContent = "0.00";
});

// 💵 Finalizar venta
document.getElementById("finalizar").addEventListener("click", () => {
  if (carrito.length === 0) { alert("El carrito está vacío."); return; }
  const total = parseFloat(document.getElementById("total").textContent.replace("$",""));
  const efectivo = parseFloat(document.getElementById("efectivo").value);
  if (isNaN(efectivo) || efectivo < total) { alert("Efectivo insuficiente."); return; }

  fetch("php/registrarVenta.php", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      usuario_id: 3, // ID del cajero logueado
      carrito: carrito
    })
  })
  .then(res => res.json())
  .then(resp => {
    if (resp.success) {
      Toastify({ text: "Venta registrada correctamente ✅", duration: 3000 }).showToast();
      carrito = [];
      contProductos.innerHTML = "";
      document.getElementById("total").textContent = "$0.00";
      carritoVacio.classList.remove("disabled");
      contProductos.classList.add("disabled");
      document.getElementById("efectivo").value = "";
      document.getElementById("cambio").textContent = "0.00";
    } else {
      alert(resp.error);
    }
  })
  .catch(err => alert("Error al registrar venta: " + err));
});

// 💱 Calcular cambio
document.getElementById("efectivo").addEventListener("input", () => {
  const total = parseFloat(document.getElementById("total").textContent.replace("$","")) || 0;
  const efectivo = parseFloat(document.getElementById("efectivo").value) || 0;
  document.getElementById("cambio").textContent = (efectivo - total).toFixed(2);
});
