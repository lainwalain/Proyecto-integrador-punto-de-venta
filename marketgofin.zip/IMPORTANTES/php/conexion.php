<?php
$host = "localhost";
$user = "root";
$pass = ""; // tu contraseña de MySQL si la tienes
$db   = "marget.go";  // 🔹 aquí pon el nombre exacto de tu base

$conexion = new mysqli($host, $user, $pass, $db);
if ($conexion->connect_error) {
  die("Error de conexión: " . $conexion->connect_error);
}
$conexion->set_charset("utf8mb4");
