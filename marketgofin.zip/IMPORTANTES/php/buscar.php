<?php
include("conexion.php");

// Fuerza charset y JSON
header('Content-Type: application/json; charset=utf-8');
$conexion->set_charset("utf8mb4");

$busqueda = $_GET['busqueda'] ?? '';
$like = "%$busqueda%";

$sql = "SELECT id, titulo AS nombre, precio, imagen, existencia
        FROM articulos
        WHERE titulo LIKE ?
        ORDER BY titulo
        LIMIT 20";

$stmt = $conexion->prepare($sql);
$stmt->bind_param("s", $like);
$stmt->execute();
$result = $stmt->get_result();

$productos = [];
while ($row = $result->fetch_assoc()) {
    // Normaliza tipos y evita valores nulos
    $row['precio'] = isset($row['precio']) ? (float)$row['precio'] : 0.0;
    $row['existencia'] = isset($row['existencia']) ? (int)$row['existencia'] : 0;
    $row['imagen'] = $row['imagen'] ?? '';
    $row['nombre'] = $row['nombre'] ?? '';
    $productos[] = $row;
}

echo json_encode($productos, JSON_UNESCAPED_UNICODE);
