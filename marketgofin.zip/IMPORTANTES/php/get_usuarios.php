<?php
include("conexion.php");
header('Content-Type: application/json; charset=utf-8');

$sql = "SELECT id, nombre, usuario, email,
        CASE rol_id
          WHEN 1 THEN 'Administrador'
          WHEN 2 THEN 'Usuario'
          WHEN 3 THEN 'Empleado'
          ELSE 'Desconocido'
        END AS rol
        FROM usuarios";
$res = $conexion->query($sql);

$data = [];
while ($row = $res->fetch_assoc()) {
  $data[] = $row;
}

echo json_encode($data, JSON_UNESCAPED_UNICODE);
