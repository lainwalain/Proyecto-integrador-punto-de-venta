<?php
header('Content-Type: application/json; charset=utf-8');

$conexion = new mysqli("localhost", "tu_usuario", "tu_password", "markett_go");

if ($conexion->connect_error) {
    die(json_encode(["error" => "Error de conexión: " . $conexion->connect_error]));
}

$sql = "SELECT id, titulo, imagen, categoria_nombre, categoria_id, precio FROM productos";
$resultado = $conexion->query($sql);

$productos = [];
while ($fila = $resultado->fetch_assoc()) {
    $productos[] = $fila;
}

echo json_encode($productos, JSON_UNESCAPED_UNICODE);
$conexion->close();
?>
