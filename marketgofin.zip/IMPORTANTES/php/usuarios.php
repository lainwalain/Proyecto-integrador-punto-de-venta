<?php
include("conexion.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $accion = $_POST['accion'] ?? '';

    if ($accion === "crear") {
        $nombre   = $_POST['nombre'];
        $usuario  = $_POST['usuario'];
        $email    = $_POST['email'];
        $password = $_POST['password'];
        $rol_id   = $_POST['rol_id'];

        // Validar que el rol exista
        $checkRol = $conexion->prepare("SELECT id FROM roles WHERE id=?");
        $checkRol->bind_param("i", $rol_id);
        $checkRol->execute();
        $res = $checkRol->get_result();

        if ($res->num_rows === 0) {
            die("Error: El rol con ID $rol_id no existe en la tabla roles.");
        }

        // Insertar usuario (con hash seguro)
        $hash = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $conexion->prepare("INSERT INTO usuarios (nombre, usuario, email, password, rol_id) VALUES (?,?,?,?,?)");
        $stmt->bind_param("ssssi", $nombre, $usuario, $email, $hash, $rol_id);

        if ($stmt->execute()) {
            echo "Usuario registrado correctamente";
        } else {
            echo "Error al registrar usuario: " . $conexion->error;
        }
    }
    elseif ($accion === "eliminar_usuario") {
        $usuarioLogin = $_POST['usuario'] ?? '';

        if ($usuarioLogin === '') {
            die("Error: Debes especificar el nombre de usuario.");
        }

        // Verificar existencia
        $checkUser = $conexion->prepare("SELECT usuario, nombre FROM usuarios WHERE usuario=?");
        $checkUser->bind_param("s", $usuarioLogin);
        $checkUser->execute();
        $res = $checkUser->get_result();

        if ($res->num_rows === 0) {
            die("Error: El usuario '$usuarioLogin' no existe.");
        }

        $usr = $res->fetch_assoc();

        // Eliminar por usuario
        $del = $conexion->prepare("DELETE FROM usuarios WHERE usuario=?");
        $del->bind_param("s", $usuarioLogin);

        if ($del->execute()) {
            echo "Usuario '" . $usr['nombre'] . "' eliminado correctamente";
        } else {
            echo "Error al eliminar usuario: " . $conexion->error;
        }
    }
}
?>
