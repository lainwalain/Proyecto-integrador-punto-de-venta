<?php
include("conexion.php");

$accion = $_POST['accion'] ?? '';

if ($accion === "crear") {
    $id = $_POST['id'];
    $titulo = $_POST['titulo'];
    $imagen = $_POST['imagen'];
    $categoria_nombre = $_POST['categoria_nombre'];
    $categoria_id = $_POST['categoria_id'];
    $precio = $_POST['precio'];

    $sql = "INSERT INTO articulos (id, titulo, imagen, categoria_nombre, categoria_id, precio)
            VALUES ('$id','$titulo','$imagen','$categoria_nombre','$categoria_id','$precio')";
    echo ($conexion->query($sql) === TRUE) ? "Artículo creado" : "Error: ".$conexion->error;
}

if ($accion === "editar") {
    $id = $_POST['id'];
    $titulo = $_POST['titulo'];
    $precio = $_POST['precio'];

    $sql = "UPDATE articulos SET titulo='$titulo', precio='$precio' WHERE id='$id'";
    echo ($conexion->query($sql) === TRUE) ? "Artículo actualizado" : "Error: ".$conexion->error;
}

if ($accion === "eliminar") {
    $id = $_POST['id'];
    $sql = "DELETE FROM articulos WHERE id='$id'";
    echo ($conexion->query($sql) === TRUE) ? "Artículo eliminado" : "Error: ".$conexion->error;
}
?>
