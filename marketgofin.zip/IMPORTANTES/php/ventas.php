<?php
include("conexion.php");

$accion = $_POST['accion'] ?? '';

if ($accion === "crear") {
    $usuario_id = $_POST['usuario_id'];
    $articulo_id = $_POST['articulo_id'];
    $cantidad = (int)$_POST['cantidad'];

    // Verificar que el usuario exista
    $checkUser = $conexion->query("SELECT id FROM usuarios WHERE id='$usuario_id'");
    if ($checkUser->num_rows === 0) {
        die("Error: El usuario con ID $usuario_id no existe.");
    }

    // Verificar que el artículo exista y obtener existencia
    $checkArt = $conexion->query("SELECT id, existencia FROM articulos WHERE id='$articulo_id'");
    if ($checkArt->num_rows === 0) {
        die("Error: El artículo con ID $articulo_id no existe.");
    }
    $articulo = $checkArt->fetch_assoc();

    // Validar existencia suficiente
    if ($articulo['existencia'] < $cantidad) {
        die("Error: No hay suficiente existencia. Disponibles: " . $articulo['existencia']);
    }

    // Registrar venta
    $sql = "INSERT INTO ventas (usuario_id, articulo_id, cantidad) 
            VALUES ('$usuario_id','$articulo_id','$cantidad')";
    if ($conexion->query($sql) === TRUE) {
        // Actualizar existencia
        $conexion->query("UPDATE articulos SET existencia = existencia - $cantidad WHERE id='$articulo_id'");
        echo "Venta registrada correctamente";
    } else {
        echo "Error al registrar venta: " . $conexion->error;
    }
}

elseif ($accion === "eliminar_usuario") {
    $id = (int)$_POST['id'];

    // Verificar que el usuario exista
    $checkUser = $conexion->query("SELECT id FROM usuarios WHERE id='$id'");
    if ($checkUser->num_rows === 0) {
        die("Error: El usuario con ID $id no existe.");
    }

    // Eliminar usuario
    if ($conexion->query("DELETE FROM usuarios WHERE id='$id'") === TRUE) {
        echo "Usuario eliminado correctamente";
    } else {
        echo "Error al eliminar usuario: " . $conexion->error;
    }
}
?>
