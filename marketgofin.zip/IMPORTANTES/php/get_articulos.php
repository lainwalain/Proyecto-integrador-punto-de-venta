<?php
include("conexion.php");
header('Content-Type: application/json; charset=utf-8');

$result = $conexion->query("SELECT * FROM articulos");
$productos = [];

while ($row = $result->fetch_assoc()) {
    $productos[] = [
        "id" => $row["id"],
        "titulo" => $row["titulo"],
        "imagen" => $row["imagen"],
        "categoria" => [
            "nombre" => $row["categoria_nombre"],
            "id" => $row["categoria_id"]
        ],
        "precio" => (float)$row["precio"],
        "existencia" => (int)$row["existencia"]
    ];
}

echo json_encode($productos, JSON_UNESCAPED_UNICODE);
?>
