<?php
session_start();
include("conexion.php");

$usuario = $_POST['usuario'];
$password = $_POST['password'];

// Consulta con JOIN para traer el nombre del rol
$sql = "SELECT usuarios.*, roles.nombre AS role 
        FROM usuarios 
        JOIN roles ON usuarios.rol_id = roles.id 
        WHERE usuario=? AND password=?";

$stmt = $conexion->prepare($sql);
$stmt->bind_param("ss", $usuario, $password);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();

    // Guardar sesión
    $_SESSION['usuario'] = $user['usuario'];
    $_SESSION['rol_id'] = $user['rol_id'];
    $_SESSION['role']   = strtolower($user['role']); // normalizamos a minúsculas

    // Redirección según rol
    switch ($_SESSION['role']) {
        case "administrador":
            header("Location: ../adminProductos.html");
            break;
        case "usuario":
            header("Location: ../index.html");
            break;
        case "empleado":
        case "cajero":
            header("Location: ../cajero.html");
            break;
        default:
            // Si el rol no coincide con ninguno de los anteriores
            header("Location: ../index.html");
            break;
    }
    exit();
} else {
    echo "<p style='color:red'>Usuario o contraseña incorrectos</p>";
    echo "<a href='../login/login.html'>Volver al login</a>";
}
?>
