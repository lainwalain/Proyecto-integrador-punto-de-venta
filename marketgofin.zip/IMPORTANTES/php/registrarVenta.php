<?php
include("conexion.php");

$data = json_decode(file_get_contents("php://input"), true);

$usuario_id = $data['usuario_id']; // el cajero logueado
$carrito    = $data['carrito'];    // array de productos con id y cantidad

foreach ($carrito as $item) {
    $articulo_id = $item['id'];
    $cantidad    = $item['cantidad'];

    // Verificar existencia
    $check = $conexion->query("SELECT existencia FROM articulos WHERE id='$articulo_id'");
    $row = $check->fetch_assoc();
    if ($row['existencia'] < $cantidad) {
        http_response_code(400);
        echo json_encode(["error" => "No hay suficiente existencia para $articulo_id"]);
        exit;
    }

    // Insertar venta
    $conexion->query("INSERT INTO ventas (usuario_id, articulo_id, cantidad) 
                      VALUES ('$usuario_id','$articulo_id','$cantidad')");

    // Actualizar existencia
    $conexion->query("UPDATE articulos SET existencia = existencia - $cantidad WHERE id='$articulo_id'");
}

echo json_encode(["success" => true]);
?>
