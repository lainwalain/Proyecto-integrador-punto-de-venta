<?php
include("conexion.php");

$nombre   = $_POST['nombre'] ?? '';
$usuario  = $_POST['usuario'] ?? '';
$email    = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';
$rol_id   = 2; // 🔹 fijo: solo rol Usuario

if ($nombre === '' || $usuario === '' || $email === '' || $password === '') {
    die("Error: Todos los campos son obligatorios.");
}

// Verificar si el usuario ya existe
$check = $conexion->prepare("SELECT id FROM usuarios WHERE usuario=? OR email=?");
$check->bind_param("ss", $usuario, $email);
$check->execute();
$result = $check->get_result();
if ($result->num_rows > 0) {
    die("Error: El usuario o correo ya está registrado.");
}

// Insertar nuevo usuario (contraseña en texto plano)
$stmt = $conexion->prepare("INSERT INTO usuarios (nombre, usuario, email, password, rol_id) VALUES (?,?,?,?,?)");
$stmt->bind_param("ssssi", $nombre, $usuario, $email, $password, $rol_id);

if ($stmt->execute()) {
    echo "Registro exitoso. Ahora puedes iniciar sesión.";
} else {
    echo "Error al registrar: " . $stmt->error;
}
?>
