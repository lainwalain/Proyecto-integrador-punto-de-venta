<?php
include("conexion.php");

// Seleccionar todos los usuarios
$result = $conexion->query("SELECT id, password FROM usuarios");

while ($row = $result->fetch_assoc()) {
    $id = $row['id'];
    $plainPassword = $row['password'];

    // Si la contraseña no está ya encriptada (ejemplo: longitud < 60)
    if (strlen($plainPassword) < 60) {
        $hash = password_hash($plainPassword, PASSWORD_BCRYPT);

        $stmt = $conexion->prepare("UPDATE usuarios SET password=? WHERE id=?");
        $stmt->bind_param("si", $hash, $id);
        $stmt->execute();

        echo "Usuario $id actualizado\n";
    }
}

echo "Proceso terminado. Todas las contraseñas fueron encriptadas.";
?>
